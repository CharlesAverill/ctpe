# Simplification

Summary

#include simpl.md

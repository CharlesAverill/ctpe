# Generalization

Summary

#include intros.md
